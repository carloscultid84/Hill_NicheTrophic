### 2. Approaches comparison ###

#### Content ####

## 2.1 Base code for traditional niche breadth measures (standarized Shannon and Levins niche breadth measures) and their confidence intervals at 95 %
## 2.2 Base code for Hill series diversity orders and their confidence intervals at 95 % at same sample coverage
## 2.3 Base code for traditional niche overlap measure (Pianka symmetric index) and its confidence intervals at 95 %
## 2.4 Base code for the estimation of the overlap of the 0, 1 and 2 orders of the Hill series
## 2.5 Figure 5
## 2.6 Figure 6

## expand or contract sections to show or hide the code

#### packages ####

library(iNEXT)
library(vegetarian)
library(abdiv)
library(vegan)
library(ggplot2)
library(dplyr)
library(gridExtra)
library(ggpubr)
library(spaa)

#### Data ####

data = read.csv("aguacate.csv", header = T, sep = ",", row.names = 1)

#### 2.1 Base code for traditional niche breadth measures (standarized Shannon and Levins niche breadth measures) and their confidence intervals at 95 % ####


## 2.1.1 standarized Shannon measure ##

## replace DA in "Remuestreo" function and "pielou_e" by the desired species


Remuestreo<-function(x){
  a<-numeric(10000) ### iterations number
  for (i in 1:10000){
    a[i]<-(pielou_e(sample(x$DA,89,replace=T)))}
  quantile(a,c(.025,.975))}

Remuestreo(data) ## confidence intervals at 95 %

pielou_e(data$DA) ## mean estimation

## 2.1.2 Standarized Levins measure ##

## replace DA in "Remuestreo" function and 60 code line by the desired species

Remuestreo<-function(x){
  a<-numeric(10000) 
  for (i in 1:10000){
    a[i]<-((invsimpson(sample(x$DA,89,replace=T)) -1) / (richness(x$DA) -1))}
  quantile(a,c(.025,.975))}

Remuestreo(data) ## confidence intervals at 95 %

(invsimpson(data$DA) -1) / (richness(data$DA) -1) ## mean estimation

#### 2.2 Base code for Hill series diversity orders and their confidence intervals at 95 % at same sample coverage ####

DataInfo(data, datatype = "abundance") ## observe "SC" for sample coverage level

estimateD(data, datatype = "abundance", base = "coverage", level = 0.718, conf = 0.95) ## compare at the minimum sample coverage level. The output showns Confidence intervals at 95 % for each species and diversity order.

#### 2.3 Base code for traditional niche overlap measure (Pianka symmetric index) and its confidence intervals at 95 % ####

# replace DA and EA in "Remuestreo" function for each desired species pair.

Remuestreo<-function(x){
  a<-numeric(10000) ### iterations number
  for (i in 1:10000){
    a[i]<-((niche.overlap.pair((sample(x$DA,89,replace=T)), (sample(x$EA,89,replace=T)), method = "pianka")))}
  c(mean(a), quantile(a,c(.025,.975)))}

Remuestreo(data) ## First value: Mean, second and third are confidence intervals at 95 %.


#### 2.4 Base code for the estimation of the overlap of the 0, 1 and 2 orders of the Hill series ####

detach("package:spaa", unload = TRUE) ## both spaa and vegetarian packages have "turnover" function, for this reason detach spaa package


# replace DA and EA in "Remuestreo" function for each desired species pair. Change q = 0 for any q desired order.


Remuestreo<-function(x){
  a<-numeric(10000) 
  for (i in 1:10000){
    a[i]<-(1-(turnover((sample(x$DA,89,replace=T)), (sample(x$EA,89,replace=T)), q= 0)))}
  c(mean(a), quantile(a,c(.025,.975)))}

Remuestreo(data) ## First value: Mean, second and third are confidence intervals at 95 %.

#### 2.5 Figure 5 ####

## data: with steps 2.1 and 2.2 build both "Qalfa_rean0.csv" and "Qalfa_rean1.csv" matrices

dlev = read.csv("Qalfa_rean0.csv", header = T, sep = ",")

## graphs

dlev$Especie = factor(dlev$Especie, levels = c("EA", "EN", "DA", "LF")) ## species ordination

shbd = ggplot(dlev, aes(x=Especie, y=mean1)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=IC95inf1, ymax=IC95sup1), width=.5, position=position_dodge(.9)) + ggtitle("A") + xlab(" ") + ylab("Niche breadth") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") + ylim(0,1) ## Standarized Shannon

lvbd = ggplot(dlev, aes(x=Especie, y=mean)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=IC95inf, ymax=IC95sup), width=.5, position=position_dodge(.9)) + ggtitle("B") + xlab(" ") + ylab(" ") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") + ylim(0,1) ## Standarized Levins


dinxt = read.csv("Qalfa_rean1.csv", header = T, sep = ",")

dinxt$Especie = factor(dinxt$Especie, levels = c("EA", "EN", "DA", "LF")) ## Species ordination

or0 = ggplot(filter(dinxt, Q=="0"), aes(x=Especie, y=mean)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=IC95inf, ymax=IC95sup), width=.5, position=position_dodge(.9)) + ggtitle("C") + xlab(" ") + ylab("Prey richness") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") ## q0

or1 = ggplot(filter(dinxt, Q=="1"), aes(x=Especie, y=mean)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=IC95inf, ymax=IC95sup), width=.5, position=position_dodge(.9)) + ggtitle("D") + xlab(" ") + ylab("Number of equally common prey") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") ## q1

or2 = ggplot(filter(dinxt, Q=="2"), aes(x=Especie, y=mean)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=IC95inf, ymax=IC95sup), width=.5, position=position_dodge(.9)) + ggtitle("E") + xlab(" ") + ylab("Effective number of dominant prey") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") ## q2


### Merge graphs

NB = grid.arrange(shbd, lvbd, or0, or1, or2, ncol = 3, nrow = 2,   layout_matrix = rbind(c(NA,1, 2),
                                                                                         c(3, 4, 5)))

annotate_figure(NB, bottom = text_grob("Species", color = "black", hjust = 0.5, face = "bold", size = 20, family = "Sans"))

#ggsave("Fig5.png", dpi = 300, height = 9, width = 9) ##Save Figure

#### 2.6 Figure 6 ####

## data: with steps 2.3 and 2.4 build "over_comp.csv" matrix

dover = read.csv("over_comp.csv", header = T, sep = ",")

## graph

dover$sp_pair = factor(dover$sp_pair, levels = c("EA-EN", "EA-DA", "EA-LF", "EN-DA", "EN-LF", "DA-LF")) ## species pair ordination

pnk = ggplot(filter(dover, ord=="Pianka"), aes(x=sp_pair, y=mean)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=low, ymax=sup), width=.5, position=position_dodge(.9)) + ggtitle("A") + xlab(" ") + ylab(" ") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") + ylim(0,1) ## Pianka symmetric index

D0 = ggplot(filter(dover, ord=="0DB"), aes(x=sp_pair, y=mean)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=low, ymax=sup), width=.5, position=position_dodge(.9)) + ggtitle("B") + xlab(" ") + ylab(" ") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") + ylim(0,1) ## 0Db

D1 = ggplot(filter(dover, ord=="1DB"), aes(x=sp_pair, y=mean)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=low, ymax=sup), width=.5, position=position_dodge(.9)) + ggtitle("C") + xlab(" ") + ylab(" ") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") + ylim(0,1) ## 1Db

D2 = ggplot(filter(dover, ord=="2DB"), aes(x=sp_pair, y=mean)) + geom_point(shape = 20, size = 5) + geom_errorbar(aes(ymin=low, ymax=sup), width=.5, position=position_dodge(.9)) + ggtitle("D") + xlab(" ") + ylab(" ") + theme_classic() + theme(text=element_text(size=14, family = "Sans"), axis.text = element_text(family = "Sans", face = "bold", size =10), plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5))+ theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), legend.justification = c(0, 1), legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), legend.direction="horizontal")+ theme(panel.background=element_rect(fill='transparent',color='black',size=1))+theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + theme(legend.position = "none") + ylim(0,1) ## 2Db


## Merge graphs

NO2 = grid.arrange(pnk, D0, D1, D2, ncol = 2, nrow = 2)

annotate_figure(NO2, left = text_grob("Overlap", color = "black", hjust = 0.5, face = "bold", size = 20, family = "Sans", rot = 90),bottom = text_grob("Species pair", color = "black", hjust = 0.5, face = "bold", size = 20, family = "Sans"))

##ggsave("Fig6.png", dpi = 300, height = 9, width = 9) ##Save Figure


