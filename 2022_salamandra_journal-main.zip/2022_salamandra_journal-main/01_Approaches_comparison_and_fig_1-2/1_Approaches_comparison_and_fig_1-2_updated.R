### 1. Approaches comparison, updated sept 2023 ###

## Contact: mario.herreralopera@gmail.com

#### Content ####

## 1.1 Base code for traditional niche breadth measures (standarized Shannon and Levins niche breadth measures) and their confidence intervals at 95 %
## 1.2 Base code for Hill series diversity orders and their confidence intervals at 95 % at same sample coverage
## 1.3 Base code for traditional niche overlap measure (Pianka symmetric index) and its confidence intervals at 95 %
## 1.4 Base code for the estimation of the overlap of the 0, 1 and 2 orders of the Hill series
## 1.5 Figure 1
## 1.6 Figure 2

## expand or contract sections to show or hide the code

#### packages ####

library(iNEXT)
library(vegetarian) ## https://cran.r-project.org/src/contrib/Archive/vegetarian/
library(abdiv)
library(vegan)
library(ggplot2)
library(dplyr)
library(gridExtra)
library(ggpubr)
library(spaa)

#### Data ####

data <- read.csv("aguacate.csv", header = T, sep = ",", row.names = 1)

#### 1.1 Base code for traditional niche breadth measures (standarized Shannon and Levins niche breadth measures) and their confidence intervals at 95 % ####

## The measures must be calculated individually for each species, i.e. a vector containing the abundances of the prey. 

## 1.1.1 standarized Shannon measure ##

## function

st.shannon <- function(x){
  a<-numeric(10000) ### iterations number
  for (i in 1:10000){
    a[i] <- (pielou_e(sample(x, length(x), replace = T)))}
  c(mean = pielou_e(x), low_IC = quantile(a, 0.025, names = F), 
    upp_IC = quantile(a, 0.975, names = F))
}

## The first value corresponds to the mean, the second to the lower 95%CI and the third to the upper 95%CI.

st.shannon(data$DA) ## for Dryophites arenicolor
st.shannon(data$EA) ## for Eleuthrodactylus angustidigitorum
st.shannon(data$EN) ## for Eleuthrodactylus nitudus
st.shannon(data$LF) ## for Lithobates forreri

## 1.1.2 Standarized Levins measure ##

## function

Levins <- function(x){
  a <- numeric(10000) ### iterations number
  for (i in 1:10000){
    a[i] <- (invsimpson(sample(x, length(x), replace = T)))}
  quantile(a, c(0.025, 0.975))
  c(mean = invsimpson(x), low_IC = quantile(a, 0.025, names = F), 
    upp_IC = quantile(a, 0.975, names = F))
}

## The first value corresponds to the mean, the second to the lower 95%CI and the third to the upper 95%CI.

Levins(data$DA) ## for Dryophites arenicolor
Levins(data$EA) ## for Eleuthrodactylus angustidigitorum
Levins(data$EN) ## for Eleuthrodactylus nitudus
Levins(data$LF) ## for Lithobates forreri

#### 1.2 Base code for Hill series diversity orders and their confidence intervals at 95 % at same sample coverage ####

DataInfo(data, datatype = "abundance") ## observe "SC" for sample coverage level

## compare at the minimum sample coverage level. The output showns Confidence intervals at 95 % for each species and diversity order.

estimateD(data, datatype = "abundance", base = "coverage", 
          level = min(DataInfo(data, datatype = "abundance")$SC),
          conf = 0.95) 

#### 1.3 Base code for traditional niche overlap measure (Pianka symmetric index) and its confidence intervals at 95 % ####

## Function

Pianka_IC <- function(x, y){
  a <- numeric(10000) ### iterations number
  for (i in 1:10000){
    a[i] <- ((niche.overlap.pair((sample(x, length(x), replace=T)), 
                                 (sample(y, length(y), replace=T)), method = "pianka")))}
  c(mean = mean(a), low_IC = quantile(a, 0.025, names = F), upp_IC = quantile(a, 0.975, names = F))
}

## The first value corresponds to the mean, the second to the lower 95%CI and the third to the upper 95%CI.

Pianka_IC(data$DA, data$EA) ## Overlap between D.arenicolor y E. angustidigitorum
Pianka_IC(data$DA, data$EN) ## Overlap between D.arenicolor y E. nitidus
Pianka_IC(data$DA, data$LF) ## Overlap between D.arenicolor y L. forreri
Pianka_IC(data$EA, data$EN) ## Overlap between E. angustidigitorum y E. nitidus
Pianka_IC(data$EA, data$LF) ## Overlap between E. angustidigitorum y L. forreri
Pianka_IC(data$EN, data$LF) ## Overlap between E. nitidus y L. forreri

#### 1.4 Base code for the estimation of the overlap of the 0, 1 and 2 orders of the Hill series ####


# function

over.hill <- function(x, y, order){
  a <- numeric(10000) 
  for (i in 1:10000){
    a[i] <- ((similarity((sample(x, length(x), replace = T)), (sample(y, length(y), replace = T)), q = order)))}
  c(mean = mean(a), low_IC = quantile(a, 0.025, names = F), upp_IC = quantile(a, 0.975, names = F))
}


## The first value corresponds to the mean, the second to the lower 95%CI and the third to the upper 95%CI.

## The first argument is species 1, the second argument is species 2 and order is the order of q.


over.hill(data$DA, data$EA, order = 0) ## Overlap between D.arenicolor y E. angustidigitorum order 0
over.hill(data$DA, data$EA, order = 1) ## Overlap between D.arenicolor y E. angustidigitorum order 1
over.hill(data$DA, data$EA, order = 2) ## Overlap between D.arenicolor y E. angustidigitorum order 2

## Replace species pairs to get the remaining values

#### 1.5 Figure 1 ####

## data: with steps 1.1 and 1.2 build both "Qalfa_rean0.csv" and "Qalfa_rean1.csv" matrices

dlev <- read.csv("Qalfa_rean0.csv", header = T, sep = ",")

## graphs

dlev$Especie = factor(dlev$Especie, levels = c("EA", "EN", "DA", "LF")) ## species ordination

shbd <- ggplot(dlev, aes(x=Especie, y=mean1)) + geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=IC95inf1, ymax=IC95sup1), width=.5, position=position_dodge(.9)) + 
  ggtitle("A") + xlab(" ") + ylab("Niche breadth") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), 
        legend.position = c(0, 1), legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") + ylim(0,1) ## Standarized Shannon

lvbd <- ggplot(dlev, aes(x=Especie, y=mean)) + geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=IC95inf, ymax=IC95sup), width=.5, position=position_dodge(.9)) + 
  ggtitle("B") + xlab(" ") + ylab(" ") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), 
        legend.position = c(0, 1), legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") + ylim(0,1) ## Standarized Levins


dinxt <- read.csv("Qalfa_rean1.csv", header = T, sep = ",")

dinxt$Especie = factor(dinxt$Especie, levels = c("EA", "EN", "DA", "LF")) ## Species ordination

or0 <- ggplot(filter(dinxt, Q=="0"), aes(x=Especie, y=mean)) + geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=IC95inf, ymax=IC95sup), width=.5, position=position_dodge(.9)) + 
  ggtitle("C") + xlab(" ") + ylab("Prey richness") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), 
        legend.position = c(0, 1), legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) +
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") ## q0

or1 <- ggplot(filter(dinxt, Q=="1"), aes(x=Especie, y=mean)) + 
  geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=IC95inf, ymax=IC95sup), width=.5, position=position_dodge(.9)) + 
  ggtitle("D") + xlab(" ") + ylab("Number of equally common prey") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), 
        legend.position = c(0, 1), legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") ## q1

or2 <- ggplot(filter(dinxt, Q=="2"), aes(x=Especie, y=mean)) + geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=IC95inf, ymax=IC95sup), width=.5, position=position_dodge(.9)) + 
  ggtitle("E") + xlab(" ") + ylab("Effective number of dominant prey") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), 
        legend.position = c(0, 1), legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") ## q2


### Merge graphs

NB <- grid.arrange(shbd, lvbd, or0, or1, or2, ncol = 3, nrow = 2, 
                   layout_matrix = rbind(c(NA,1, 2), c(3, 4, 5)))

annotate_figure(NB, bottom = text_grob("Species", color = "black", 
                                       hjust = 0.5, face = "bold", size = 20, family = "Sans"))

#ggsave("Fig1.png", dpi = 300, height = 9, width = 9) ##Save Figure

#### 1.6 Figure 2 ####

## data: with steps 1.3 and 1.4 build "over_comp.csv" matrix

dover <- read.csv("over_comp.csv", header = T, sep = ",")

## graph

dover$sp_pair = factor(dover$sp_pair, levels = c("EA-EN", "EA-DA", "EA-LF", 
                                                 "EN-DA", "EN-LF", "DA-LF")) ## species pair ordination

pnk <- ggplot(filter(dover, ord=="Pianka"), aes(x=sp_pair, y=mean)) + geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=low, ymax=sup), width=.5, position=position_dodge(.9)) + 
  ggtitle("A") + xlab(" ") + ylab(" ") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), legend.position = c(0, 1), 
        legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") + ylim(0,1) ## Pianka symmetric index

D0 <- ggplot(filter(dover, ord=="0DB"), aes(x=sp_pair, y=mean)) + geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=low, ymax=sup), width=.5, position=position_dodge(.9)) + ggtitle("B") + 
  xlab(" ") + ylab(" ") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), 
        legend.position = c(0, 1), legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") + ylim(0,1) ## 0Db

D1 <- ggplot(filter(dover, ord=="1DB"), aes(x=sp_pair, y=mean)) + geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=low, ymax=sup), width=.5, position=position_dodge(.9)) + ggtitle("C") + 
  xlab(" ") + ylab(" ") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), 
        legend.position = c(0, 1), legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") + ylim(0,1) ## 1Db

D2 <- ggplot(filter(dover, ord=="2DB"), aes(x=sp_pair, y=mean)) + geom_point(shape = 20, size = 5) + 
  geom_errorbar(aes(ymin=low, ymax=sup), width=.5, position=position_dodge(.9)) + ggtitle("D") + 
  xlab(" ") + ylab(" ") + 
  theme_classic() + 
  theme(text=element_text(size=14, family = "Sans"), 
        axis.text = element_text(family = "Sans", face = "bold", size =10), 
        plot.title = element_text(family = "Sans", face = "bold", size = 14, hjust=0.5)) + 
  theme(legend.text = element_text(colour = "black", size = 12, family = "Sans"), 
        legend.position = c(0, 1), legend.justification = c(0, 1), 
        legend.background = element_rect(fill="white", size=0.5, linetype="solid", colour = "black"), 
        legend.direction="horizontal") + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(panel.background=element_rect(fill='transparent',color='black',size=1)) + 
  theme(legend.position = "none") + ylim(0,1) ## 2Db


## Merge graphs

NO2 <- grid.arrange(pnk, D0, D1, D2, ncol = 2, nrow = 2)

annotate_figure(NO2, left = text_grob("Overlap", color = "black", hjust = 0.5, face = "bold", 
                                      size = 20, family = "Sans", rot = 90),
                bottom = text_grob("Species pair", color = "black", hjust = 0.5, face = "bold", 
                                   size = 20, family = "Sans"))

##ggsave("Fig2.png", dpi = 300, height = 9, width = 9) ##Save Figure
